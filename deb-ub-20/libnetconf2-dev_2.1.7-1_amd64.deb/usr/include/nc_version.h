/**
 * @file nc_version.h
 * @author Michal Vasko <mvasko@cesnet.cz>
 * @brief libnetconf2 version information
 *
 * @copyright
 * Copyright (c) 2021 CESNET, z.s.p.o.
 *
 * This source code is licensed under BSD 3-Clause License (the "License").
 * You may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://opensource.org/licenses/BSD-3-Clause
 */

#ifndef NC_VERSION_H_
#define NC_VERSION_H_

#ifdef __cplusplus
extern "C" {
#endif

#define NC_VERSION_MAJOR 3 /**< libnetconf2 major version number */
#define NC_VERSION_MINOR 1 /**< libnetconf2 minor version number */
#define NC_VERSION_MICRO 3 /**< libnetconf2 micro version number */
#define NC_VERSION "3.1.3" /**< libnetconf2 version string */

#ifdef __cplusplus
}
#endif

#endif /* NC_VERSION_H_ */
